package com.deskpet.cat;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.view.View;

import java.util.HashSet;
import java.util.Set;

/** Vẽ NGUYÊN ẢNH Bongo Cat gốc (cat.png). Tay chuột và tay phím cử động bằng cách
 *  uốn lưới ảnh (drawBitmapMesh), nên hình không bị đổi, không bị lộ viền. */
public class CatView extends View {
    private static final int MW = 48, MH = 27;
    private static final float IW = 480f, IH = 270f;
    private static final int[][] ROWS = {
            {2, 3, 4, 5, 6, 7, 8, 9, 10, 11},
            {16, 17, 18, 19, 20, 21, 22, 23, 24, 25},
            {30, 31, 32, 33, 34, 35, 36, 37, 38},
            {44, 45, 46, 47, 48, 49, 50}};

    private final Bitmap bmp;
    private final Paint paint = new Paint(Paint.FILTER_BITMAP_FLAG | Paint.ANTI_ALIAS_FLAG);
    private final int n = (MW + 1) * (MH + 1);
    private final float[] bx = new float[n], by = new float[n];
    private final float[] wl = new float[n], wr = new float[n];
    private final float[] verts = new float[n * 2];
    private final Set<Integer> keys = new HashSet<>();
    private int mouseBtns;
    private float offX, offY, pawDx, pawDy, tgtDx, clickY;

    public CatView(Context c) {
        super(c);
        BitmapFactory.Options o = new BitmapFactory.Options();
        o.inScaled = false;
        bmp = BitmapFactory.decodeResource(getResources(), R.drawable.cat, o);
        for (int j = 0; j <= MH; j++)
            for (int i = 0; i <= MW; i++) {
                int k = j * (MW + 1) + i;
                float x = i * IW / MW, y = j * IH / MH;
                bx[k] = x; by[k] = y;
                wl[k] = weight(x, y, 75, 162, 95, 60);   // tay trái + chuột
                wr[k] = weight(x, y, 338, 190, 60, 50);  // tay phải + bàn phím
            }
    }

    private static float weight(float x, float y, float cx, float cy, float rx, float ry) {
        double r = Math.hypot((x - cx) / rx, (y - cy) / ry);
        float t = (float) Math.max(0, Math.min(1, (r - 0.45) / 0.55));
        return 1 - t * t * (3 - 2 * t);
    }

    private float keyFrac(int code) {
        for (int[] row : ROWS)
            for (int j = 0; j < row.length; j++)
                if (row[j] == code) return (j + 0.5f) / row.length;
        return 0.5f;
    }

    public void onMove(int dx, int dy) {
        offX = Math.max(-14, Math.min(14, offX + dx * 0.35f));
        offY = Math.max(-9, Math.min(9, offY + dy * 0.35f));
        invalidate();
    }

    public void onKey(int code, boolean down) {
        if (code >= 272 && code <= 274) {
            int bit = 1 << (code - 272);
            if (down) mouseBtns |= bit; else mouseBtns &= ~bit;
            clickY = mouseBtns != 0 ? 3 : 0;
        } else if (down) {
            keys.add(code);
            tgtDx = (keyFrac(code) - 0.5f) * 24f;
        } else {
            keys.remove(code);
        }
        invalidate();
    }

    @Override
    protected void onDraw(Canvas cv) {
        if (bmp == null) return;
        float s = getWidth() / IW;
        offX *= 0.9f; offY *= 0.9f;
        float tdy = keys.isEmpty() ? 0f : 6f;
        pawDx += (tgtDx - pawDx) * 0.4f;
        pawDy += (tdy - pawDy) * 0.5f;
        clickSm += (clickY - clickSm) * 0.5f;
        for (int k = 0; k < n; k++) {
            verts[2 * k] = (bx[k] + offX * wl[k] + pawDx * wr[k]) * s;
            verts[2 * k + 1] = (by[k] + (offY + clickSm) * wl[k] + pawDy * wr[k]) * s;
        }
        cv.drawBitmapMesh(bmp, MW, MH, verts, 0, null, 0, paint);
        boolean moving = Math.abs(offX) > 0.05f || Math.abs(offY) > 0.05f
                || Math.abs(tgtDx - pawDx) > 0.05f || Math.abs(tdy - pawDy) > 0.05f
                || Math.abs(clickY - clickSm) > 0.05f;
        if (moving) postInvalidateOnAnimation();
    }

    private float clickSm;

    @Override
    protected void onMeasure(int w, int h) {
        int width = MeasureSpec.getSize(w);
        setMeasuredDimension(width, Math.round(width * IH / IW));
    }
}
