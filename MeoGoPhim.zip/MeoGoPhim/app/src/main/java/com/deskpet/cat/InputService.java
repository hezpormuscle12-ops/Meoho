package com.deskpet.cat;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

/** Chạy với quyền shell. Đọc TẤT CẢ thiết bị /dev/input/event*, kể cả chuột ảo (uinput)
 *  của GG Mouse Pro, và quét lại liên tục để bắt thiết bị cắm/tạo mới. */
public class InputService extends IInputService.Stub {
    private volatile IInputCallback cb;
    private volatile boolean running;
    private final Set<String> active = Collections.synchronizedSet(new HashSet<String>());

    public InputService() {}

    @Override
    public void destroy() {
        running = false;
        System.exit(0);
    }

    @Override
    public void start(IInputCallback callback) {
        cb = callback;
        if (running) return;
        running = true;
        Thread t = new Thread(new Runnable() {
            @Override public void run() { scanLoop(); }
        });
        t.setDaemon(true);
        t.start();
    }

    private void scanLoop() {
        while (running) {
            File[] fs = new File("/dev/input").listFiles();
            if (fs != null) {
                for (final File f : fs) {
                    if (!f.getName().startsWith("event")) continue;
                    if (active.add(f.getPath())) {
                        Thread t = new Thread(new Runnable() {
                            @Override public void run() { readDevice(f); }
                        });
                        t.setDaemon(true);
                        t.start();
                    }
                }
            }
            try { Thread.sleep(1500); } catch (InterruptedException ignored) {}
        }
    }

    private void readDevice(File f) {
        final int size = android.os.Process.is64Bit() ? 24 : 16; // struct input_event
        final int off = size - 8;
        byte[] buf = new byte[size];
        ByteBuffer bb = ByteBuffer.wrap(buf).order(ByteOrder.LITTLE_ENDIAN);
        int dx = 0, dy = 0;
        long last = 0;
        try (FileInputStream in = new FileInputStream(f)) {
            while (running) {
                int n = 0;
                while (n < size) {
                    int r = in.read(buf, n, size - n);
                    if (r < 0) throw new IOException("eof");
                    n += r;
                }
                int type = bb.getShort(off) & 0xffff;
                int code = bb.getShort(off + 2) & 0xffff;
                int value = bb.getInt(off + 4);
                IInputCallback c = cb;
                if (c == null) continue;
                if (type == 2) {                       // EV_REL
                    if (code == 0) dx += value;        // REL_X
                    else if (code == 1) dy += value;   // REL_Y
                } else if (type == 1 && value != 2) { // EV_KEY (bỏ auto-repeat)
                    if ((code >= 1 && code <= 255) || (code >= 272 && code <= 274)) {
                        c.onKey(code, value == 1);
                    }
                } else if (type == 0 && code == 0 && (dx != 0 || dy != 0)) { // EV_SYN
                    long now = System.nanoTime();
                    if (now - last > 8_000_000L) {     // gộp ~120 lần/giây
                        c.onMove(dx, dy);
                        dx = 0; dy = 0; last = now;
                    }
                }
            }
        } catch (Exception ignored) {
        } finally {
            active.remove(f.getPath());
        }
    }
}
