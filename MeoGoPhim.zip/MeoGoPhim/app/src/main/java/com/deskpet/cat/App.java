package com.deskpet.cat;

import android.app.Application;

import java.io.File;
import java.io.PrintWriter;

public class App extends Application {
    @Override
    public void onCreate() {
        super.onCreate();
        final Thread.UncaughtExceptionHandler old = Thread.getDefaultUncaughtExceptionHandler();
        Thread.setDefaultUncaughtExceptionHandler(new Thread.UncaughtExceptionHandler() {
            @Override public void uncaughtException(Thread t, Throwable e) {
                try {
                    PrintWriter w = new PrintWriter(new File(getFilesDir(), "crash.txt"));
                    e.printStackTrace(w);
                    w.close();
                } catch (Exception ignored) {}
                if (old != null) old.uncaughtException(t, e);
            }
        });
    }
}
