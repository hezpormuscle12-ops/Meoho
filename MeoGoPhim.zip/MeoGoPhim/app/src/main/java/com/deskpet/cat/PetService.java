package com.deskpet.cat;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.ComponentName;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;

import rikka.shizuku.Shizuku;

public class PetService extends Service {
    static volatile boolean running;

    private WindowManager wm;
    private CatView cat;
    private WindowManager.LayoutParams lp;
    private SharedPreferences sp;
    private final Handler h = new Handler(Looper.getMainLooper());
    private boolean bound;
    private Shizuku.UserServiceArgs args;

    private final IInputCallback.Stub cb = new IInputCallback.Stub() {
        @Override public void onMove(final int dx, final int dy) {
            h.post(new Runnable() { @Override public void run() { if (cat != null) cat.onMove(dx, dy); } });
        }
        @Override public void onKey(final int code, final boolean down) {
            h.post(new Runnable() { @Override public void run() { if (cat != null) cat.onKey(code, down); } });
        }
    };

    private final ServiceConnection conn = new ServiceConnection() {
        @Override public void onServiceConnected(ComponentName n, IBinder b) {
            try { IInputService.Stub.asInterface(b).start(cb); } catch (Exception e) { bound = false; }
        }
        @Override public void onServiceDisconnected(ComponentName n) { bound = false; }
    };

    /** Chạy 3 giây/lần: dựng lại mèo nếu bị mất, cập nhật khóa cảm ứng, nối lại Shizuku. */
    private final Runnable watchdog = new Runnable() {
        @Override public void run() {
            try {
                if (cat != null && !cat.isAttachedToWindow()) {
                    try { wm.addView(cat, lp); } catch (Exception ignored) {}
                }
                applyLock();
                tryBind();
            } catch (Throwable ignored) {}
            h.postDelayed(this, 3000);
        }
    };

    private void tryBind() {
        if (bound) return;
        try {
            if (Shizuku.pingBinder() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) {
                Shizuku.bindUserService(args, conn);
                bound = true;
            }
        } catch (Throwable ignored) {}
    }

    private void applyLock() {
        if (lp == null || cat == null) return;
        boolean lk = sp.getBoolean("lock", false);
        int nf = lk ? (lp.flags | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE)
                    : (lp.flags & ~WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE);
        if (nf != lp.flags) {
            lp.flags = nf;
            try { wm.updateViewLayout(cat, lp); } catch (Exception ignored) {}
        }
    }

    private int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density); }

    @Override
    public void onCreate() {
        super.onCreate();
        running = true;
        sp = getSharedPreferences("pet", MODE_PRIVATE);
        startForeground(1, buildNotification());
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        cat = new CatView(this);
        int w = dp(300);
        lp = new WindowManager.LayoutParams(w, Math.round(w * 270f / 480f),
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.START;
        lp.x = sp.getInt("x", dp(20));
        lp.y = sp.getInt("y", dp(200));
        cat.setOnTouchListener(new View.OnTouchListener() {
            float sx, sy; int ox, oy;
            @Override public boolean onTouch(View v, MotionEvent e) {
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        sx = e.getRawX(); sy = e.getRawY(); ox = lp.x; oy = lp.y; return true;
                    case MotionEvent.ACTION_MOVE:
                        lp.x = ox + (int) (e.getRawX() - sx);
                        lp.y = oy + (int) (e.getRawY() - sy);
                        try { wm.updateViewLayout(cat, lp); } catch (Exception ignored) {}
                        return true;
                    case MotionEvent.ACTION_UP:
                        sp.edit().putInt("x", lp.x).putInt("y", lp.y).apply();
                        return true;
                }
                return false;
            }
        });
        if (sp.getBoolean("lock", false)) lp.flags |= WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE;
        try {
            wm.addView(cat, lp);
        } catch (Exception e) {
            stopSelf();
            return;
        }
        args = new Shizuku.UserServiceArgs(new ComponentName(getPackageName(), InputService.class.getName()))
                .daemon(false).processNameSuffix("input").version(1);
        h.post(watchdog);
    }

    private Notification buildNotification() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel("pet", "Mèo", NotificationManager.IMPORTANCE_LOW);
            getSystemService(NotificationManager.class).createNotificationChannel(ch);
        }
        Notification.Builder b = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this, "pet") : new Notification.Builder(this);
        PendingIntent pi = PendingIntent.getActivity(this, 0,
                new Intent(this, MainActivity.class), PendingIntent.FLAG_IMMUTABLE);
        return b.setContentTitle("Mèo đang chạy").setContentText("Chạm để mở app, tắt mèo trong app")
                .setSmallIcon(android.R.drawable.ic_dialog_info).setContentIntent(pi).build();
    }

    @Override public int onStartCommand(Intent i, int f, int id) { return START_STICKY; }
    @Override public IBinder onBind(Intent i) { return null; }

    @Override
    public void onDestroy() {
        running = false;
        h.removeCallbacksAndMessages(null);
        try { if (cat != null) wm.removeView(cat); } catch (Exception ignored) {}
        cat = null;
        try { if (args != null) Shizuku.unbindUserService(args, conn, true); } catch (Throwable ignored) {}
        super.onDestroy();
    }
}
