package com.deskpet.cat;

import com.deskpet.cat.IInputCallback;

interface IInputService {
    void destroy() = 16777114;
    void start(IInputCallback cb) = 1;
}
