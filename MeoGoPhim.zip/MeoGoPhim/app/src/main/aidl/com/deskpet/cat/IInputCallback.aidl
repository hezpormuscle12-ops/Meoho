package com.deskpet.cat;

oneway interface IInputCallback {
    void onMove(int dx, int dy);
    void onKey(int code, boolean down);
}
